package com.example.bluetooth

import ESP32BLE
import MusicListAdapter
import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.skydoves.colorpickerview.ColorPickerDialog
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener


class MainActivity : AppCompatActivity() {

    private lateinit var esp32Ble: ESP32BLE
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var musicList: ListView
    private lateinit var seekBar: SeekBar
    private lateinit var musicFiles: ArrayList<String>
    private var isMediaPlayerPrepared = false

    @SuppressLint("MissingPermission")


    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                esp32Ble.startScan()
            } else {
                Toast.makeText(
                    this,
                    "Location permission denied. App functionality may be limited.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

//    private val requestStoragePermissionLauncher =
//        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
//            if (isGranted) {
//                loadMusicFiles()
//                setupSearchView()
//            } else {
//                Toast.makeText(
//                    this,
//                    "Storage permission denied. App functionality may be limited.",
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//        }

//    private val requestManageStoragePermissionLauncher =
//        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
//            if (isGranted) {
//                loadMusicFiles()
//                setupSearchView()
//            } else {
//                Toast.makeText(
//                    this,
//                    "Manage storage permission denied. App functionality may be limited.",
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//        }



    private val enableBtLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                Toast.makeText(this, "Bluetooth enabled", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    "Bluetooth not enabled. App functionality may be limited.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        esp32Ble = ESP32BLE(this)

        if (!esp32Ble.isBluetoothEnabled()) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBtLauncher.launch(enableBtIntent)
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

//        if (ContextCompat.checkSelfPermission(
//                this,
//                Manifest.permission.READ_EXTERNAL_STORAGE
//            ) != PackageManager.PERMISSION_GRANTED
//        ) {
//            requestStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
//        }


        



        setupUI()
    }

    private fun setupUI() {
        val connectDisconnectButton = findViewById<Button>(R.id.button_connect)

        esp32Ble.connectionListener = { status ->
            runOnUiThread {
                when (status) {
                    ESP32BLE.BluetoothConnectionStatus.CONNECTED -> {
                        connectDisconnectButton.text = getString(R.string.button_disconnect)
                        Toast.makeText(this, "Connected to ESP32", Toast.LENGTH_SHORT).show()
                    }
                    ESP32BLE.BluetoothConnectionStatus.CONNECTING -> {
                        connectDisconnectButton.text = getString(R.string.button_connecting)
                        Toast.makeText(this, "Connecting to ESP32...", Toast.LENGTH_SHORT).show()
                    }
                    ESP32BLE.BluetoothConnectionStatus.DISCONNECTED -> {
                        connectDisconnectButton.text = getString(R.string.button_connect)
                        Toast.makeText(this, "Disconnected from ESP32", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        connectDisconnectButton.setOnClickListener {
            if (esp32Ble.getConnectionStatus() == ESP32BLE.BluetoothConnectionStatus.CONNECTED) {
                esp32Ble.disconnect()
                connectDisconnectButton.text = "Connect"
            } else {
                esp32Ble.connect()
                connectDisconnectButton.text = "Disconnect"
            }
        }

        val ledOnButton = findViewById<Button>(R.id.button_on)
        ledOnButton.setOnClickListener {
            if (esp32Ble.getConnectionStatus() == ESP32BLE.BluetoothConnectionStatus.CONNECTED) {
                esp32Ble.sendMessage("1")
            } else {
                Toast.makeText(this, "Not connected to ESP32. Please connect first.", Toast.LENGTH_SHORT).show()
            }
        }

        val ledOffButton = findViewById<Button>(R.id.button_off)
        ledOffButton.setOnClickListener {
            if (esp32Ble.getConnectionStatus() == ESP32BLE.BluetoothConnectionStatus.CONNECTED) {
                esp32Ble.sendMessage("0")
            } else {
                Toast.makeText(this, "Not connected to ESP32. Please connect first.", Toast.LENGTH_SHORT).show()
            }
        }

        val greenButton = findViewById<Button>(R.id.Green)
        greenButton.setOnClickListener {
            if (esp32Ble.getConnectionStatus() == ESP32BLE.BluetoothConnectionStatus.CONNECTED) {
                esp32Ble.sendMessage("2")
            } else {
                Toast.makeText(this, "Not connected to ESP32. Please connect first.", Toast.LENGTH_SHORT).show()
            }
        }

        val redButton = findViewById<Button>(R.id.Red)
        redButton.setOnClickListener {
            if (esp32Ble.getConnectionStatus() == ESP32BLE.BluetoothConnectionStatus.CONNECTED) {
                esp32Ble.sendMessage("3")
            } else {
                Toast.makeText(this, "Not connected to ESP32. Please connect first.", Toast.LENGTH_SHORT).show()
            }
        }

        val blueButton = findViewById<Button>(R.id.Blue)
        blueButton.setOnClickListener {
            if (esp32Ble.getConnectionStatus() == ESP32BLE.BluetoothConnectionStatus.CONNECTED) {
                esp32Ble.sendMessage("4")
            } else {
                Toast.makeText(this, "Not connected to ESP32. Please connect first.", Toast.LENGTH_SHORT).show()
            }
        }

        val randomButton = findViewById<Button>(R.id.randomize)
        randomButton.setOnClickListener {
            if (esp32Ble.getConnectionStatus() == ESP32BLE.BluetoothConnectionStatus.CONNECTED) {
                esp32Ble.sendMessage("5")
            } else {
                Toast.makeText(this, "Not connected to ESP32. Please connect first.", Toast.LENGTH_SHORT).show()
            }
        }

        val builder = ColorPickerDialog.Builder(this)
            .setTitle("ColorPicker Dialog")
            .setPreferenceName("MyColorPickerDialog")
            .setPositiveButton(getString(android.R.string.ok),
                ColorEnvelopeListener { envelope, fromUser -> // Handle color selection
                    val selectedColor = envelope.color
                })
            .setNegativeButton(
                getString(android.R.string.cancel)
            ) { dialogInterface, i -> dialogInterface.dismiss() }

        builder.show()


    }


//    private fun setupSearchView() {
//        val searchView = findViewById<SearchView>(R.id.search_music)
//        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
//            override fun onQueryTextSubmit(query: String?): Boolean {
//                return false
//            }
//
//            override fun onQueryTextChange(newText: String?): Boolean {
//                Log.d("SearchQuery", "Search Query: $newText")
//                val allMusicFiles = loadMusicFiles()
//                val filteredMusicFiles = allMusicFiles.filter { it.contains(newText ?: "", ignoreCase = true) }
//                displayMusicFiles(ArrayList(filteredMusicFiles))
//                return true
//            }
//        })
//    }


    private fun loadMusicFiles(): ArrayList<String> {
        val musicResolver = contentResolver
        val musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val selection = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND (" + MediaStore.Audio.Media.MIME_TYPE + "=? OR " + MediaStore.Audio.Media.MIME_TYPE + "=?)"
        val selectionArgs = arrayOf("audio/mpeg", "audio/ogg")
        val musicCursor = musicResolver.query(musicUri, null, null, null, null)

        val musicFiles = ArrayList<String>()

        if (musicCursor != null && musicCursor.moveToFirst()) {
            val titleColumn = musicCursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
            val dataIndex = musicCursor.getColumnIndex(MediaStore.Audio.Media.DATA) // Get the data index

            do {
                val title = musicCursor.getString(titleColumn)
                val data = musicCursor.getString(dataIndex) // Get the file path
                Log.d("MusicFiles", "Title: $title, FilePath: $data") // Log the file path
                musicFiles.add(title)
            } while (musicCursor.moveToNext())
        }

        Log.d("FilteredMusicFiles", "Total Filtered Music Files: ${musicFiles.size}")
        for (file in musicFiles) {
            Log.d("FilteredMusicFiles", "Filtered Music File: $file")
        }

        musicCursor?.close()

        return musicFiles
    }

    private fun displayMusicFiles(musicFiles: ArrayList<String>) {
        val musicAdapter = MusicListAdapter(this, android.R.layout.simple_list_item_1, musicFiles)
        musicList.adapter = musicAdapter
        musicAdapter.notifyDataSetChanged()
    }


    private lateinit var visualizer: Visualizer

    private fun initMediaPlayer() {
        mediaPlayer = MediaPlayer()

        mediaPlayer.setOnCompletionListener {
            mediaPlayer.seekTo(0)
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}

            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        musicList.setOnItemClickListener { _, _, position, _ ->
            mediaPlayer.reset()
            isMediaPlayerPrepared = false // Add this line

            val musicResolver = contentResolver
            val musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val musicCursor = musicResolver.query(musicUri, null, null, null, null)

            if (musicCursor != null && musicCursor.moveToPosition(position)) {
                val dataIndex = musicCursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val filePath = musicCursor.getString(dataIndex)

                mediaPlayer.setDataSource(filePath)
                mediaPlayer.prepareAsync()

                mediaPlayer.setOnPreparedListener {
                    isMediaPlayerPrepared = true // Add this line
                    mediaPlayer.start()
                    setupVisualizer()
                }
            }

            musicCursor?.close()
        }

        updateSeekBar()
    }

    private fun setupVisualizer() {
        visualizer = Visualizer(mediaPlayer.audioSessionId).apply {
            captureSize = Visualizer.getCaptureSizeRange()[1]
            scalingMode = Visualizer.SCALING_MODE_NORMALIZED
            setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer, waveform: ByteArray, samplingRate: Int) {
                    // Convert the waveform ByteArray to a String and send it to ESP32
                    val waveformString = String(waveform)
                    esp32Ble.sendMessage(waveformString)
                }

                override fun onFftDataCapture(visualizer: Visualizer, fft: ByteArray, samplingRate: Int) {
                    // You can also capture FFT data here if needed
                }
            }, Visualizer.getMaxCaptureRate() / 2, true, false)

            enabled = true
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
        if (::visualizer.isInitialized) {
            visualizer.release()
        }
    }



    private fun updateSeekBar() {
        if (isMediaPlayerPrepared) { // Add this line
            seekBar.max = mediaPlayer.duration
        } // Add this line

        val handler = Handler(Looper.getMainLooper())

        val updateSeekBarRunnable = object : Runnable {
            override fun run() {
                if (mediaPlayer.isPlaying && isMediaPlayerPrepared) { // Add "isMediaPlayerPrepared" to the condition
                    seekBar.progress = mediaPlayer.currentPosition
                }
                handler.postDelayed(this, 100)
            }
        }

        handler.post(updateSeekBarRunnable)
    }


//    private fun openDancingVisualizerFragment() {
//        val dancingVisualizerFragment = DancingVisualizerFragment()
//        supportFragmentManager.beginTransaction()
//            .replace(R.id.container_dancing_visualizer, dancingVisualizerFragment)
//            .addToBackStack(null)
//            .commit()
//    }

    private fun requestStoragePermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )

        val requestCode = 101
        ActivityCompat.requestPermissions(this, permissions, requestCode)
    }

//    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        when (requestCode) {
//            101 -> {
//                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    loadMusicFiles()
//                    setupSearchView()
//                } else {
//                    Toast.makeText(this, "Permission denied. App functionality may be limited.", Toast.LENGTH_SHORT).show()
//                }
//            }
//        }
//    }


    @SuppressLint("MissingPermission")
    override fun onPause() {
        super.onPause()
        esp32Ble.stopScan()
        esp32Ble.disconnect()
    }
}
