import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.util.Log
import androidx.annotation.RequiresPermission
import java.util.UUID

class ESP32BLE(private val context: Context) {
    enum class BluetoothConnectionStatus {
        CONNECTED,
        CONNECTING,
        DISCONNECTED
    }

    companion object {
        private val ESP32_SERVICE_UUID =UUID.fromString("000000ff-0000-1000-8000-00805f9b34fb")
        private val ESP32_CHARACTERISTIC_UUID = UUID.fromString("0000ff01-0000-1000-8000-00805f9b34fb")
        private const val TAG = "ESP32BLE"
    }

    private val bluetoothAdapter: BluetoothAdapter by lazy {
        BluetoothAdapter.getDefaultAdapter()
    }

    private var bluetoothGatt: BluetoothGatt? = null
    private var connectionStatus: BluetoothConnectionStatus = BluetoothConnectionStatus.DISCONNECTED

    var connectionListener: ((BluetoothConnectionStatus) -> Unit)? = null

    fun isBluetoothEnabled(): Boolean {
        return bluetoothAdapter.isEnabled
    }

    fun getConnectionStatus(): BluetoothConnectionStatus {
        return connectionStatus
    }

    private var bluetoothDevice: BluetoothDevice? = null

    @SuppressLint("MissingPermission")
    fun connect() {
        if (isBluetoothEnabled()) {
            if (bluetoothDevice != null) {
                connectToDevice(bluetoothDevice!!)
            } else {
                startScan()
            }
        } else {
            Log.w("ESP32BLE", "Bluetooth is not enabled. Enable Bluetooth before connecting.")
        }
    }

    @SuppressLint("MissingPermission")
    @RequiresPermission(Manifest.permission.ACCESS_FINE_LOCATION)
    fun startScan() {
        if (isBluetoothEnabled()) {
            val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()

            bluetoothAdapter.bluetoothLeScanner.startScan(null, settings, scanCallback)
        } else {
            Log.w(TAG, "Bluetooth is not enabled. Enable Bluetooth before starting a scan.")
        }
    }

    @SuppressLint("MissingPermission")
    @RequiresPermission(Manifest.permission.ACCESS_FINE_LOCATION)
    fun stopScan() {
        if (isBluetoothEnabled()) {
            bluetoothAdapter.bluetoothLeScanner.stopScan(scanCallback)
        } else {
            Log.w(TAG, "Bluetooth is not enabled. Enable Bluetooth before stopping a scan.")
        }
    }


    @SuppressLint("NewApi", "MissingPermission")
    fun sendMessage(message: String) {
        bluetoothGatt?.let { gatt ->
            val service = gatt.getService(ESP32_SERVICE_UUID)
            val characteristic = service?.getCharacteristic(ESP32_CHARACTERISTIC_UUID)
            characteristic?.let {
                it.setValue(message.toByteArray())
                val result = gatt.writeCharacteristic(it)
                Log.d(TAG, "sendMessage: sent $message, result: $result")
            } ?: run {
                Log.w(TAG, "sendMessage: characteristic not found")
            }
        } ?: run {
            Log.w(TAG, "sendMessage: not connected to a device")
        }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            Log.d(TAG, "onScanResult: ${result.device.name} - ${result.device.address}")

            val deviceName = "ESP32" // Replace this with the name of your ESP32 device
            if (result.device.name == deviceName && connectionStatus != BluetoothConnectionStatus.CONNECTED) {
                stopScan()
                bluetoothDevice = result.device
                connectToDevice(result.device)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            super.onScanFailed(errorCode)
            Log.e(TAG, "Scan failed with error code: $errorCode")
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(device: BluetoothDevice) {
        if (connectionStatus == BluetoothConnectionStatus.CONNECTED) {
            return
        }
        stopScan()
        connectionListener?.invoke(BluetoothConnectionStatus.CONNECTING)
        bluetoothGatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
                super.onConnectionStateChange(gatt, status, newState)
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    connectionStatus = BluetoothConnectionStatus.CONNECTED
                    connectionListener?.invoke(connectionStatus)
                    gatt?.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connectionStatus = BluetoothConnectionStatus.DISCONNECTED
                    connectionListener?.invoke(connectionStatus)
                    gatt?.close()
                }
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
                super.onServicesDiscovered(gatt, status)
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    Log.i(TAG, "Services discovered.")
                } else {
                    Log.w(TAG, "Service discovery failed.")
                }
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        if (connectionStatus == BluetoothConnectionStatus.CONNECTED || connectionStatus == BluetoothConnectionStatus.CONNECTING) {
            bluetoothGatt?.disconnect()
            bluetoothGatt?.close()
            bluetoothGatt = null
            connectionStatus = BluetoothConnectionStatus.DISCONNECTED
            connectionListener?.invoke(connectionStatus)
        }
    }
}
