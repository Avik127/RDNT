import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter
import java.util.ArrayList

class MusicListAdapter(
    context: Context,
    private val layout: Int,
    private val allMusicFiles: ArrayList<String>
) : ArrayAdapter<String>(context, layout, allMusicFiles) {

    private val musicFilesFiltered: ArrayList<String> = ArrayList(allMusicFiles)

    override fun getCount(): Int {
        return musicFilesFiltered.size
    }

    override fun getItem(position: Int): String {
        return musicFilesFiltered[position]
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = ArrayList<String>()
                if (constraint == null || constraint.isEmpty()) {
                    filteredList.addAll(allMusicFiles)
                } else {
                    val filterPattern = constraint.toString().toLowerCase().trim()
                    for (item in allMusicFiles) {
                        if (item.toLowerCase().contains(filterPattern)) {
                            filteredList.add(item)
                        }
                    }
                }
                val results = FilterResults()
                results.values = filteredList
                return results
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                musicFilesFiltered.clear()
                musicFilesFiltered.addAll(results?.values as List<String>)
                notifyDataSetChanged()
            }
        }
    }
}
